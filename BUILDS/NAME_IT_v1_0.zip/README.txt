# NAME IT

NAME IT watches a folder and complains whenever a new file shows up.

## HOW TO USE

1. Run NAME IT.exe.
2. Click "START WORKING".
3. Choose the folder you want to monitor.
4. Keep working normally.
5. When a new file is created, NAME IT will let you know what it thinks about the name.

## AGGRESSION

Choose how hard NAME IT should complain:

POLITE
NORMAL
ANNOYING
UNHINGED

The more questionable your filenames are, the worse it gets.

## PAUSE

Use "PAUSE 30 MIN" if you need NAME IT to shut up for a while.

## IMPORTANT

NAME IT does not rename, move, delete, or modify your files.

It only watches them and judges their names.

That's it.

Name your files properly.
